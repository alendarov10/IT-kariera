﻿using System;
public class Program
{
    public static void Main()
    {
        int a = int.Parse(Console.ReadLine());
        int b = int.Parse(Console.ReadLine());
        int s = a * b;
        Console.WriteLine(s);
    }
}