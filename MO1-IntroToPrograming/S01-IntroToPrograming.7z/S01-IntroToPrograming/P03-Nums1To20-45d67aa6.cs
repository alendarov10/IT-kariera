﻿using System;
public class Program
{
    public static void Main()
    {
        for (int i = 1; i <= 20; i++)
        {
            Console.WriteLine(i);
        }
    }
}
